package com.EmployeeManagementapplication;


import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EmployeeServiceTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testEmployeeService() {
		//fail("Not yet implemented");
	}

	@Test
	void testViewAllEmps() {
		//fail("Not yet implemented");
	}

	@Test
	void testViewEmp() {
		//fail("Not yet implemented");
	}

	@Test
	void testUpdateEmployee() {
		//fail("Not yet implemented");
	}

	@Test
	void testDeleteEmp() {
		//fail("Not yet implemented");
	}

	@Test
	void testAddEmp() {
		//fail("Not yet implemented");
	}

}
