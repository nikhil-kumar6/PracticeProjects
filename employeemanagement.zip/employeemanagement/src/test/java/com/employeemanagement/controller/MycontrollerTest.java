package com.employeemanagement.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MycontrollerTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
