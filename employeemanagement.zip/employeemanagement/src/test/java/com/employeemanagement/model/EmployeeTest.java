package com.employeemanagement.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class EmployeeTest {

	@Test
	void testEmployee() {
		fail("Not yet implemented");
	}

	@Test
	void testGetId() {
		fail("Not yet implemented");
	}

	@Test
	void testSetId() {
		fail("Not yet implemented");
	}

	@Test
	void testGetName() {
		fail("Not yet implemented");
	}

	@Test
	void testSetName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetSalary() {
		fail("Not yet implemented");
	}

	@Test
	void testSetSalary() {
		fail("Not yet implemented");
	}

	@Test
	void testGetUsername() {
		fail("Not yet implemented");
	}

	@Test
	void testSetUsername() {
		fail("Not yet implemented");
	}

	@Test
	void testGetPassword() {
		fail("Not yet implemented");
	}

	@Test
	void testSetPassword() {
		fail("Not yet implemented");
	}

	@Test
	void testGetState() {
		fail("Not yet implemented");
	}

	@Test
	void testSetState() {
		fail("Not yet implemented");
	}

	@Test
	void testGetCity() {
		fail("Not yet implemented");
	}

	@Test
	void testSetCity() {
		fail("Not yet implemented");
	}

	@Test
	void testGetPincode() {
		fail("Not yet implemented");
	}

	@Test
	void testSetPincode() {
		fail("Not yet implemented");
	}

}
